.jrnotes2 = new.env()
.jrnotes2$error = FALSE
.jrnotes2$error_funs = NULL
.jrnotes2$missing_deps = NULL
