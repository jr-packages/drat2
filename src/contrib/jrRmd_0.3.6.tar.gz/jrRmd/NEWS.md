# jrRmd 0.3.6 _2020-09-28_
  * Admin: Updated package title
