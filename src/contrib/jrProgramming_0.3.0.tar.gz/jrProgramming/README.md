<!-- README.md is generated from README.Rmd. Please edit that file -->
Programming with R
==================

[![Build Status](https://api.travis-ci.org/jr-packages/jrProgramming.png?branch=master)](https://travis-ci.org/jr-packages/jrProgramming.png)

Course material for the [Programming with R](https://www.jumpingrivers.com) course.
