# jrNotesCI 0.3.0 _2021-09-07_
  * Bug: R pkg version check now implemented
  
# jrNotesCI 0.2.* _2021-07-20_
  * Feature: Install pip packages from config
  * Feature: Add `update_website()` function
  * Feature: Always get the root directory for config.yml. 
  This should also fix a bug in the current CI.
  * Feat: Install local python packages in the CI
  * Feat: check package versions
  * Internal: Move python pkg functions to {jrNotes2}
  * Internal: Remove pip packages. Now just python_pkgs
