check_pkg = function(dir = ".", ...) {
  cli::cli_alert_info("Setting directory to {dir}")
  op = setwd(dir)
  on.exit(setwd(op))
  if (Sys.getenv("RELEASE") == "TRUE")
    inteRgrate::check_all(...)
  else {
    Sys.setenv("NO_IMPORTS" = 100)
    Sys.setenv("ALLOWED_NOTES" = 100)
    inteRgrate::check_pkg()
  }
}

#' Check the pkgs directory
#'
#' Runs inteRgrate::check_all() on all R packages found in pkgs/.
#' If RELEASE="FALSE", then a basic package check is performed, i.e. check_pkg with
#' no restriction on imports and notes.
#' @export
check_pkgs = function() {
  cli::cli_h2("Checking R packages...check_pkgs()")
  remotes::update_packages()
  ## No package state
  if (!file.exists("r_pkgs")) {
    cli::cli_alert_info("No pkgs found")
    return(invisible(NULL))
  }

  ## Multiple pkgs
  dirs = list.files("r_pkgs", full.names = TRUE)
  cli::cli_alert_info("Found {length(dirs)} pkgs...checking")
  sapply(dirs, function(i) check_pkg(dir = i, tag = FALSE, version = TRUE))
  return(invisible(NULL))
}
