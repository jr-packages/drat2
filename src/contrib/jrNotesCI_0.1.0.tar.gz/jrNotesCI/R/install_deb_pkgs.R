#' Install Debian packages
#'
#' Extracts deb_packages from config.yml and installs
#' @export
apt_update = function() {
  system2("apt-get", "update")
}

#' @rdname apt_update
#' @param update Run apt-get update first?
#' @export
apt_install = function(update = TRUE) {
  cli::cli_h2("Installing Debian packages")
  deb_pkgs = yaml::read_yaml("config.yml")$deb_packages
  if (isTRUE(update) && !is.null(deb_pkgs)) {
    apt_update()
  }
  if (is.null(deb_pkgs)) {
    cli::cli_alert_info("No deb pkgs found")
  } else {
    system2("apt-get", args = c("install", "-y", deb_pkgs))
  }
  return(invisible(deb_pkgs))
}
