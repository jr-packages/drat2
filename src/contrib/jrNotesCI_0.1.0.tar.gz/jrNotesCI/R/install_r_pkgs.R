#' @rdname apt_update
#' @export
r_install = function(update = TRUE) {
  cli::cli_h2("Installing R packages")
  if (isTRUE(update)) {
    remotes::update_packages()
  }

  dirs = list.files("r_pkgs", full.names = TRUE)
  cli::cli_alert_info("Found {length(dirs)} in r_pkgs...installing pkg + imports/suggests")
  sapply(dirs, function(i) remotes::install_local(i, dependencies = TRUE))

  r_pkgs = yaml::read_yaml("config.yml")$r_pkgs
  if (is.null(r_pkgs)) {
    cli::cli_alert_info("No R pkgs found")
  }
  # Ignores NULLS
  remotes::install_cran(r_pkgs, dependencies = TRUE)
  return(invisible(r_pkgs))
}
