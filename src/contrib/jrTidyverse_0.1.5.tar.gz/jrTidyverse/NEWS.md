## 0.1.4
  * Remove notes

## 0.1.2

  * Remove odd `x = 1` boxplot example
  * Clarify `alpha` and points