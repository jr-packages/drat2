## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, cache= TRUE, results = "hide", fig.align = "center", fig.keep='none')

## ---- message=FALSE, echo = TRUE-----------------------------------------
library("tidyverse")
data(names, package = "jrTidyverse")

## ------------------------------------------------------------------------
names %>% 
  mutate(name = str_trim(name)) %>% 
  mutate(name = str_to_title(name)) %>% 
  count(name) %>% 
  arrange(n)

## ---- echo = TRUE--------------------------------------------------------
data(movies, package = "jrTidyverse")

## ------------------------------------------------------------------------
length(str_subset(movies$title, pattern = "The"))

## ------------------------------------------------------------------------
# not for me!
str_subset("movies$title", pattern = "Theo")

## ------------------------------------------------------------------------
movies = movies %>% 
  mutate(title_length = str_count(title))

## ------------------------------------------------------------------------
movies %>% 
  summarise(max(title_length))

## ------------------------------------------------------------------------
movies %>% 
  filter(title_length == max(title_length)) %>% 
  select(title)

## ---- message = FALSE----------------------------------------------------
movies %>% 
  ggplot(aes(x = title_length)) + 
  geom_histogram()

## ------------------------------------------------------------------------
movies %>% 
  ggplot(aes(x = title_length, y = rating)) + 
  geom_point()

