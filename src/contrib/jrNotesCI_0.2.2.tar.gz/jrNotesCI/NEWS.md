# jrNotesCI 0.2.2 _2021-03-03_
  * Feature: Add `update_website()` function
  * Internal: Move python pkg functions to {jrNotes2}
  * Internal: Remove pip packages. Now just python_pkgs
  * Bug: `get_root_dir()`
  * Feat: Install local python packages in the CI
  * Feat: check package versions
  * Initialise
