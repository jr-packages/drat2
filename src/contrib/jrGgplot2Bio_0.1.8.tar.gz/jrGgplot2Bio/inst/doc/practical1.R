## ----echo=FALSE---------------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- echo = TRUE-------------------------------------------------------------
library("ggplot2")

## ---- echo = TRUE-------------------------------------------------------------
data(outbreaks, package = "jrGgplot2Bio")

## ----results='hide', echo = TRUE----------------------------------------------
head(outbreaks)
colnames(outbreaks)
dim(outbreaks)

## ----fig.keep='none', echo = TRUE, warning=FALSE------------------------------
ggplot(data = outbreaks) +
  geom_point(aes(x = illnesses, y = hospitalizations))

## ----cache=TRUE, echo = TRUE--------------------------------------------------
g = ggplot(data = outbreaks)
g1 = g + geom_point(aes(x = illnesses, y = hospitalizations))

## ----fig.keep='none', echo = TRUE, warning=FALSE------------------------------
g + geom_point(aes(x = illnesses, y = hospitalizations, colour = species))

## ----fig.keep='none', tidy=FALSE, cache=TRUE, echo = TRUE, warning=FALSE------
g + geom_point(aes(x = illnesses, y = hospitalizations, colour = species,
                   alpha = status))

## ----fig.keep='none', echo = TRUE, warning=FALSE------------------------------
g + geom_point(aes(x = illnesses, y = hospitalizations, colour = "Blue"))

## ----fig.keep='none', echo = TRUE, warning=FALSE------------------------------
g + geom_point(aes(x = illnesses, y = hospitalizations), colour = "Blue")

## ----fig.keep='none', echo = TRUE---------------------------------------------
g + geom_boxplot(aes(x = species, y = illnesses))

## ----fig.keep='none', cache=TRUE, tidy=FALSE, echo = TRUE---------------------
g + geom_boxplot(aes(x = species, y = illnesses, colour = factor(year)))

## ----eval=FALSE, echo = TRUE--------------------------------------------------
#  g + geom_boxplot(aes(x = species, y = illnesses, colour = year))

## ----fig.keep='none', tidy=FALSE, echo = TRUE---------------------------------
g + geom_boxplot(aes(x = species, y = illnesses, colour = factor(year)))

## ----fig.keep='none', tidy=FALSE, echo = TRUE---------------------------------
g + geom_boxplot(aes(x = species, y = illnesses, colour = factor(year))) +
  geom_point(aes(x = species, y = illnesses))


## ----fig.keep='none', tidy=FALSE, echo = TRUE---------------------------------
g + 
  geom_jitter(aes(x = species, y = illnesses)) +
  geom_boxplot(aes(x = species, y = illnesses, colour = factor(year)))

## ---- echo=TRUE---------------------------------------------------------------
data(yeast, package = "jrGgplot2Bio")

## ----fig.keep='none', echo = TRUE---------------------------------------------
g = ggplot(yeast)
g + geom_bar(aes(x = class))

## ----fig.keep='none', echo = TRUE, message=FALSE------------------------------
library(dplyr)
class_counts = yeast %>% count(class)

## ----fig.keep='none', echo = TRUE---------------------------------------------
class_counts$class = reorder(class_counts$class, class_counts$n)

## ----fig.keep='none', echo = TRUE---------------------------------------------
g = ggplot(class_counts)
g + geom_bar(aes(x = class, y = n), stat = "identity")

## ----fig.keep='none', tidy=FALSE, echo = TRUE---------------------------------
g + 
  geom_bar(aes(x = class, y = n), stat = "identity") +
  coord_flip()

## ----echo=FALSE, fig.margin = TRUE, fig.cap="Barplot with ordered bars and axes flipped", fig.height = 4----
g + 
  geom_bar(aes(x = class, y = n), stat = "identity") +
  coord_flip()

## ----eval=FALSE, echo=TRUE----------------------------------------------------
#  vignette("solutions1", package = "jrGgplot2Bio")

