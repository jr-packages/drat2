python_poetry_build_one = function(dir) {
  cli::cli_alert_info("Building {dir}")
  wd = setwd(dir)
  on.exit(setwd(wd))
  target_loc = file.path(get_root_dir(), "ci_python_pkgs")
  system2("/bin/bash", args = c("-c", shQuote("make build")))
  src_tar = list.files("dist", pattern = "\\.tar\\.gz$", full.names = TRUE)
  file.copy(src_tar, target_loc)
  file.remove(src_tar)
  return(invisible(target_loc))
}

get_python_version = function(dir) {
  fname = list.files(dir, pattern = "*\\.toml$", full.names = TRUE)
  toml = readLines(fname)
  toml = toml[stringr::str_starts(toml, "version")]
  version = stringr::str_extract(toml, "[0-9]*\\.[0-9]*\\.[0-9]*")
  version
}


get_python_name = function(dir) {
  fname = list.files(dir, pattern = "*\\.toml$", full.names = TRUE)
  toml = readLines(fname)
  toml = toml[stringr::str_starts(toml, "name")]
  name = stringr::str_match(toml, '\\"(.*)\\"')[1, 2]
  name
}

create_python_tars = function() {
  cli::cli_h2("Building local Python packages")
  root = get_root_dir()
  con = yaml::read_yaml(file.path(root, "config.yml"))
  if (is.null(con$python_pkgs)) {
    cli::cli_alert_info("No python packages specified in config")
    return(invisible(NULL))
  }

  python_pkgs = file.path(root, "python_pkgs")
  if (!dir.exists(python_pkgs)) {
    cli::cli_alert_info("No python pkg source found")
    return(invisible(NULL))
  }

  target_loc = file.path(get_root_dir(), "ci_python_pkgs")
  dir.create(target_loc, showWarnings = FALSE)

  py_pkgs = file.path(get_root_dir(), "python_pkgs")
  pkgs = list.dirs(py_pkgs, full.names = TRUE, recursive = FALSE)
  for (pkg in pkgs) {
    pkg_name = paste0(get_python_name(pkg), "-", get_python_version(pkg), ".tar.gz")
    if (!file.exists(file.path(target_loc, pkg_name))) {
      cli::cli_alert_info("Creating local .tar.gz of {pkg_name}")
      ## Delete old packages
      old_pkgs = fs::dir_ls(target_loc, regexp = paste0("/", pkg, "-"))
      fs::file_delete(old_pkgs)
      python_poetry_build_one(pkg)
    }
  }

  return(invisible(NULL))
}
