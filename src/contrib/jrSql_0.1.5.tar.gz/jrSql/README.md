# jrSQL
[![Build status](https://travis-ci.org/jr-packages/jrSql.svg?branch=master)](https://travis-ci.org/jr-packages/jrSql)
