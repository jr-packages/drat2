# jrRSConnect 0.0.2 _2020-10-29_

  * Internal: Pass InteRgrate checks

