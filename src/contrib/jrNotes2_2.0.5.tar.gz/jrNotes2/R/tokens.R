tokenise = function() {
  msg_start("Creating tokens...tokenise()")
  notes_dir = file.path(get_root_dir(), "notes")
  fname = system.file("extdata", "extractor.tex",
                      package = "jrNotes2", mustWork = TRUE)

  file.copy(fname, to = file.path(notes_dir, "extractor.tex"), overwrite = TRUE)
  if (!file.exists(file.path(notes_dir, "index.tex"))) stop("Missing index.tex file")

  file.copy(file.path(notes_dir, "index.tex"),
            file.path(notes_dir, "extractor-tmp.tex"),
            overwrite = TRUE)
  system2("xelatex",
          args = c("'\\input extractor \\input extractor-tmp.tex'"),
          stdout = FALSE)
  msg_success("Tokens created")
}

globalVariables("text")
read_tokens = function() {
  fname = file.path(get_root_dir(), "notes", "extractor.csv")
  tokens = utils::read.delim(fname, sep = "|",
                             header = FALSE,
                             col.names = c("X1", "X2", "X3"),
                             stringsAsFactors = FALSE)

  tibble::as_tibble(tokens)
}
