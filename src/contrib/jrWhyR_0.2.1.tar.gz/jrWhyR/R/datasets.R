#' Game of thrones
#'
#' Viewing figures 
#' @name GoT
#' @docType data
#' @return A data frame
#' @keywords datasets
NULL

#' Starbucks
#'
#' Products
#' @name starbucks
#' @docType data
#' @return A data frame
#' @keywords datasets
NULL

#' Jr Stock Price
#'
#' Our stock price
#' @name stock
#' @docType data
#' @return A data frame
#' @keywords datasets
NULL
