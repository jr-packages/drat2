# jrTidyverse2 0.1.407 _2020-09-18_
  * Change package title to "Jumping Rivers: Next Steps in the Tidyverse"

# jrTidyverse2 0.1.406 _2020-09-08_
  * Change package title

# jrTidyverse2 0.1.405 _2020-07-15_
  * Addings news.md
  * Adding **stopwords** to imports
  * Getting package to pass inteRgrate checks
