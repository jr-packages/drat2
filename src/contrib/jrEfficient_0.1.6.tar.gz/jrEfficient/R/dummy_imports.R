#' @import rbenchmark
NULL
