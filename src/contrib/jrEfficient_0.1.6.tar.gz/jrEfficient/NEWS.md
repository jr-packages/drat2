# jrEfficient 0.1.6 _2020-09-02_

  * Update course package name to match notes
  * Add NEWS.md
