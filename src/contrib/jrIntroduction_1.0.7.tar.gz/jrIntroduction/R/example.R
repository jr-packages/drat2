#' Example data frame data
#'
#' Used only for the introduction to data frames example
#'
#'@name example
#'@docType data
#'@usage data(example)
#'@return A data frame
#'@keywords datasets
#'@examples
#' data(example)
NULL
