# jrNotesCI 0.1.7 _2021-03-02_
  * Bug: `update_website()`

# jrNotesCI 0.1.6 _2021-02-28_
  * Feature: Add `update_website()` function

# jrNotesCI 0.1.5 _2021-01-10_
  * Internal: Move python pkg functions to jrNotes2
  * Internal: Remove pip packages. Now just python_pkgs

# jrNotesCI 0.1.4 _2021-01-09_
  * Bug: `get_root_dir()`

# jrNotesCI 0.1.3 _2021-01-08_
  * Feat: Install local python packages in the CI

# jrNotesCI 0.1.2 _2021-01-05_
  * Feat: check package versions

# jrNotesCI 0.1.1 _2020-12-30_
  * Bug

# jrNotesCI 0.1.0 _2020-12-22_
  * Initialise
