## jrNotesCI

This isn't in r_pkgs/ because in this package is required for the CI to run. The CI
in turns builds and installs the pkgs found in r_pkgs/

We could put it in a separate repo, but it just seem a little nicer being here.
