git init website-brand
cd website-brand
git config user.name "Jumping Rivers"
git config user.email "ci@jumpingrivers.com"
git config --global push.default simple

echo "Fetching Repo"
git remote add upstream "https://oauth2:$WEBSITE_TOKEN@gitlab.com/jumpingrivers/brand/corporate-website"
git fetch --depth 1 upstream

git checkout -b website-$CI_PROJECT_NAME


