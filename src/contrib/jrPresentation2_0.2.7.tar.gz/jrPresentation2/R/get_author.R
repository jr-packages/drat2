#' Presentation author and twitter handle
#'
#' Returns a nicely formatted name and twitter handle.
#' @importFrom glue glue
#' @param user By default grabs the system name and matches user.
#' @examples
#' get_author(user = "ncsg3")
#' @export
get_author = function(user = NULL) {

  if (is.null(user))
    user = Sys.info()["user"]

  authors = list(
    colin = "Colin Gillespie",
    ncsg3 = "Colin Gillespie",
    jamie = "Jamie Owen",
    theo = "Theo Roe",
    rhian = "Rhian Davies",
    john = "John McIntyre",
    jack = "Jack Walton",
    russ = "Russ Hyde"
  )

  twitter_handle = list(
    colin = "csgillespie",
    ncsg3 = "csgillespie",
    jamie = "jamieRowen",
    theo = "theoJRivers1",
    rhian = "statsrhian"
  )

  if (user %in% names(authors)) {
    author = authors[user]
  } else {
    author = "Jumping Rivers"
  }

  if (user %in% names(twitter_handle)) {
    handle = twitter_handle[user]
  } else {
    handle = "jumping_uk"
  }

  glue::glue("{author} ({twitter_link_from_handle(handle)})")
}

twitter_link_from_handle = function(handle) {
  glue::glue("[\\@{handle}](https://twitter.com/{handle})")
}
