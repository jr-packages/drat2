#' Create a local copy of a messy script
#'
#' This function will attempt to create a
#' local copy of a messy script
#' @usage get_messy_script()
#' @return logical TRUE if the operation was successful
#' @export

get_messy_script = function() {
  fpath = system.file("messy_script.R", package = "jrBestPractices")
  copy_loc = paste0(getwd(), "/", "messy_script.R")
  if (file.exists(copy_loc)) {
    stop("You have already copied this file.")
  }
  if (!nchar(fpath)) {
    stop("Something wen't wrong, package internal file could not be found.")
  }
  if (!file.copy(fpath, copy_loc)) {
    stop("Couldn't copy the file, you may not have permission to write to this
          directory.")
  }
  TRUE
}
