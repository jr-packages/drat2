
<!-- README.md is generated from README.Rmd. Please edit that file -->

# jrIntroduction

The goal of jrIntroduction is to …

## Installation

You can install jrIntroduction from github with:

``` r
install.packages("devtools")
devtools::install_github("jr-packages/jrIntroduction")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```
