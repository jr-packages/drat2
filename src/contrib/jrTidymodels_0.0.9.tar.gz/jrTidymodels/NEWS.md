# jrTidymodels 0.0.9 _2020-09-17_
  * Add kknn pkg to Imports (more annoying CI)

# jrTidymodels 0.0.8 _2020-09-17_
  * Add kknn pkg to Suggests (annoying CI)

# jrTidymodels 0.0.7 _2020-09-17_
  * Add kknn + e1071 pkgs to Imports

# jrTidymodels 0.0.6 _2020-09-17_
  * Add kknn pkg to Suggests

# jrTidymodels 0.0.5 _2020-09-17_
  * Add e1071 pkg to Suggests

# jrTidymodels 0.0.4 _2020-09-17_
  * Add caret pkg to Imports

# jrTidymodels 0.0.3 _2020-09-17_
  * Add mixture_example data
  * Add boundary_plot.R
  * Add mixture_example.R
  * Update Dockerfile

# jrTidymodels 0.0.2 _2020-09-16_
  * Add tibble pkg to Imports

# jrTidymodels 0.0.1 _2020-09-16_
  * Initial pkg template
  * Add NEWS.md
