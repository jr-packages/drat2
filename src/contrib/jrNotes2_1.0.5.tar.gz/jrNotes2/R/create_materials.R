check_optipng = function() {
  optipng_status = Sys.which("optipng")
  if (nchar(optipng_status) == 0) {
    msg_error("optipng installation required - 'sudo apt install optipng'")
    return(invisible(NULL))
  }
}

#' A function used to extract pre-defined pages from
#' main.pdf and convert them into images
#' @importFrom pdftools pdf_convert pdf_length
#' @importFrom stringr str_split
#' @export
create_materials = function() {
  root_dir = get_root_dir()
  if (!file.exists(file.path(root_dir, "notes"))) return(invisible(NULL))

  msg_start("Creating materials...create_materials()")
  check_optipng()
  # Parse and extract numbers from pages
  con = get_config()
  pages = con$website$materials
  if (is.null(pages)) {
    msg_warning("No page numbers defined in config.yml")
    return(invisible(NULL))
  }
  pages = unlist(stringr::str_split(pages, ", "))
  pages = as.numeric(pages)
  if (pages[1] != 1 || pages[2] != 2) {
    msg_error("First two page numbers in config.yml should be 1 & 2")
    return(invisible(NULL))
  }

  # Extract root directory
  main_pdf = file.path(root_dir, "notes", "main.pdf")

  # Total number of pages in main.pdf
  total_pages = pdftools::pdf_length(main_pdf)
  if (any(pages > total_pages)) {
    msg_error(paste("Remove page numbers greater than", total_pages, "listed in config.yml"))
    return(invisible(NULL))
  }

  # Delete old pages then start from scratch
  materials_dir = file.path(root_dir, "website", "materials")
  if (file.exists(materials_dir)) fs::file_delete(materials_dir)
  fs::dir_create(materials_dir)

  # Generate vector of target file paths
  target_paths = file.path(materials_dir,
                           paste0("page", stringr::str_pad(pages, 2, pad = "0"), ".png"))

  # Convert parsed pdf pages to png's
  pdftools::pdf_convert(main_pdf, pages = pages, format = "png",
                        filenames = target_paths, dpi = 150)

  # Optimising the images using optipng
  for (page in target_paths) {
    system2("optipng", args = page)
  }
  msg_success("Materials created!")
  return(invisible(NULL))
}
