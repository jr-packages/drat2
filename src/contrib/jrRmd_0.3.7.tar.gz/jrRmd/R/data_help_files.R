#' Food consumption figures for countries in Europe
#'
#' Taken from a larger data set of the world
#'
#'@name food
#'@docType data
#'@return A tibble or data frame.
#'@keywords datasets
#'@examples
#' data(food)
NULL

#' @name lsd
#' @title LSD & Maths
#' @description Group of volunteers was given LSD,
#' their mean scores on math exam and
#' tissue concentrations of LSD were obtained at n=7 time points.
#'
#' The test score is out of 100 and the Drugs is (ppm).
#' @source https://www.ncbi.nlm.nih.gov/pubmed/5676802
#' @docType data
NULL

#' @name mental_health
#' @title Mental health data
#'
#' This dataset is from a 2014 survey that measures
#' attitudes towards mental health and frequency of mental health
#' disorders in the tech workplace.
#'
#' @return A data frame with 1235 rows and 15 variables.
#' \describe{
#' \item{age.}{Age of individual.}
#' \item{year.}{Year of release.}
#' \item{country.}{The country they live in.}
#' \item{state.}{State they live in if they live in the
#' United States. If not, NA}
#' \item{self_employed.}{If they are self-employed or not.}
#' \item{family_history.}{If they have a family history of
#' mental illness}
#' \item{treatment.}{Have they sought treatment for a mental
#' health condition?}
#' \item{work_interfere.}{If a mental health condition interferes
#' with their work, if they have one.}
#' \item{no_employees.}{Number of employees the company or organisation
#' has.}
#' \item{remote_work}{If they work remotely (outside of an office) at
#' least 50 percent of the time?}
#' \item{tech_company}{Is their employer primarily a tech
#' company or organization?}
#' \item{employer_benefits}{If the employer provides mental health
#' beenfits.}
#' \item{care_options}{If they know the options for mental health care
#' their employer provides.}
#' \item{wellness_program}{If their employer has ever discussed mental
#' health as part of an employee wellness program.}
#' \item{anonymity}{Is their anonymity protected if they choose to
#' take advantage of mental health or substance abuse treatment}
#' \item{leave}{Is it easy to take medical leave for a mental
#' health condition?}}
#' @source A kable dataset
#' @docType data
NULL
