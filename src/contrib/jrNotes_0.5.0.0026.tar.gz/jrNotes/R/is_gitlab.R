is_gitlab = function() nchar(Sys.getenv("GITLAB_CI")) != 0
