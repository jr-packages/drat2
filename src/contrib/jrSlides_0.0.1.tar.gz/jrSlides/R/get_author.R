#' Presentation author and twitter handle
#'
#' Returns a nicely formatted name and twitter handle.
#' @examples
#' get_author()
#' @export
get_author = function() {
  jr_name = Sys.getenv("jr_name", NA)
  jr_twitter = Sys.getenv("jr_twitter", NA)

  if (is.na(jr_name)) {
    msg = glue::glue("{symbol$info} Specify your name in .Renviron via jr_name.
                      Falling back to 'Jumping Rivers'.")
    message(yellow(msg))
    jr_name = "Jumping Rivers"
  }

  if (is.na(jr_twitter)) {
    msg = glue::glue("{symbol$info} Specify your twitter handle in .Renviron via jr_twitter.
                      Falling back to 'jumping_uk'.")
    message(yellow(msg))
    jr_twitter = "jumping_uk"
  }
  glue::glue("{jr_name} ([\\@{jr_twitter}](https://twitter.com/{jr_twitter}))")
}
