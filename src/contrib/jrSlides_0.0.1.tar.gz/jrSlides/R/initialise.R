initialise = function() {
  # Clone gitlab-template
  # .gitignore, Makefile. index.Rmd
}
