add_header = function(border = "standard") {
  if (border == "none") return("")
  # nolint start
  css_class = "jr-header"
  if (border == "inverse") css_class = paste0(css_class, "-inverse")
  html = glue::glue('
      <div class="{css_class}">
        <img class="logo" src="assets/header-jr-white-logo.png"/>
        <span class="social">
          <table><tr>
            <td>
              <img src="assets/header-twitter.gif"/>
            </td>
            <td>@jumping_uk</td></tr>
          </table>
        </span>
      </div>')
  stringr::str_squish(html)
  # nolint end
}

add_footer = function(border = "standard") {
  if (border == "none") return("")
  # nolint start
  css_class = "jr-footer"
  if (border == "inverse") css_class = paste0(css_class, "-inverse")
  year = strsplit(as.character(Sys.Date()), split = "-")[[1]][1]
  html = glue::glue('
              <div class="{css_class}">
                <span>&copy; {year} Jumping Rivers (jumpingrivers.com)
                </span>
                <div>
                  {zzz$url}
                </div>
              </div>')
  stringr::str_squish(html)
  # nolint end
}

#' @title Add Border to Slides
#' @description Functions to add a header, footer or both.
#' @param layout Default TRUE
#' @param border Default standard. Other values are \code{inverse} or \code{none}
#' @param background_image Default \code{NULL}
#' @param background_size One of \code{cover} or \code{contain}
#' @param inverse Default FALSE
#' @param hor_align Default \code{left}. Other values are center and right
#' @param ver_align Default top. Other values middle and bottom
#' @param autosize Default NULL. Used to autosize mp4 videos.
#' @export
styler = function(layout = TRUE,
                  border = c("standard", "inverse", "none"),
                  background_image = NULL,
                  background_size = c("cover", "contain"),
                  inverse = FALSE,
                  hor_align = c("left", "center", "right"),
                  ver_align = c("top", "middle", "bottom"),
                  autosize = NULL) {
  txt = "\n"
  if (isTRUE(layout)) txt = glue::glue("layout: true")

  ## Add images
  if (!is.null(background_image)) {
    if (background_image == "jr") {
      background_image = "assets/title-jr-white-logo.png"
    }

    if (!file.exists(background_image)) stop("Image doesn't exist", call. = FALSE)
    txt = glue::glue("{txt}
               background-image: url({background_image})
               background-size: {background_size[1]}")
  }
  hor_align = match.arg(hor_align)
  ver_align = match.arg(ver_align)

  txt = glue::glue("{txt}\n class: {hor_align[1]}, {ver_align[1]}")
  ## Add class tags
  if (isTRUE(inverse)) {
    txt = glue::glue("{txt}, inverse")
  }

  if (!is.null(autosize)) {
    txt = glue::glue("inverse: {autosize}")
  }

  ## Add header/footers
  ## Make sure this goes at the end, as HTML seems to mess update the coding
  border = match.arg(border)
  if (border != "none") {
    txt = glue::glue("{txt}
                   {add_header(border)}
                   {add_footer(border)}")
  }
  ## Add trailing linebreak
  glue("{txt}\n\n---\n\n")
}
