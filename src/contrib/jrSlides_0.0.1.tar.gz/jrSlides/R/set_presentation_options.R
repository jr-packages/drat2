add_assets = function() {
  assets_dir = system.file("assets", package = "jrSlides")
  dir.create("assets", showWarnings = FALSE)
  fnames = list.files(assets_dir, full.names = TRUE)
  file.copy(fnames, "assets", overwrite = TRUE)
  return(invisible(NULL))
}

add_css = function(page_numbers) {
  css_dir = system.file("css",  package = "jrSlides")
  dir.create("css", showWarnings = FALSE)
  if (page_numbers) {
    css = file.path(css_dir, "style.css")
  } else {
    css = file.path(css_dir, "style_no_page_numbers.css")
  }
  file.copy(css, "css/style.css", overwrite = TRUE)
  return(invisible(NULL))
}

#' @importFrom clisymbols symbol
set_knitr_options = function(comment = "#>",
                             echo = TRUE,
                             collapse = TRUE,
                             cache = TRUE,
                             fig.align = "center",
                             fig.pos = "t",
                             out.width = "70%",
                             fig.width = 6,
                             fig.asp = 0.618,  # 1 / phi,
                             dev = "svg", ...) {
  msg = glue::glue("{symbol$circle_filled} Setting knitr options...set_knitr_options()")
  message(yellow(msg))
  knitr::opts_chunk$set(
    comment = comment,
    echo = echo,
    collapse = collapse,
    cache = cache,
    fig.align = fig.align,
    fig.pos = fig.pos,
    out.width = out.width,
    fig.width = fig.width,
    fig.asp = fig.asp,  # 1 / phi,
    dev = dev,
    ...
  )
  if (file.exists("config.yml")) {
    con = config::get()
    if (!is.null(con$knitr)) {
      do.call(knitr::opts_chunk$set, con$knitr)
    }
  }
  return(invisible(NULL))
}

set_options = function(digits = 3,
                       dplyr.print_min = 4,
                       dplyr.print_max = 4,
                       ...) {
  msg = glue::glue("{symbol$circle_filled} Setting options...set_options()")
  message(yellow(msg))
  options(digits = digits,
          dplyr.print_min = dplyr.print_max,
          dplyr.print_max = dplyr.print_min,
          ...
  )
  # con = config::get()
  # if (!is.null(con$options)) {
  #   do.call(knitr::opts_chunk$set, con$knitr)
  # }
  return(invisible(NULL))
}

set_seed = function() {
  con = config::get()
  if (!is.null(con$seed)) {
    set.seed(con$seed)
  }
  return(invisible(NULL))
}

#' @title Set slide Options
#'
#' @description In the future, pass the options as arguments.
#' @param page_numbers Boolean Add page numbers to the slides
#' @param url Character (default "") optional link to slide deck
#' @export
set_presentation_options = function(page_numbers = FALSE,
                                    url = "") {
  op = options(htmltools.dir.version = FALSE)
  on.exit(options(op))

  if (page_numbers && nchar(url) > 0) {
    message("Can't display both page numbers and url - pick one greedy.")
    message("Just displaying page numbers")
    url = ""
  }
  set_knitr_options()
  set_options()
  add_css(page_numbers)
  add_assets()

  zzz$url = url
  return(invisible(NULL))
}
