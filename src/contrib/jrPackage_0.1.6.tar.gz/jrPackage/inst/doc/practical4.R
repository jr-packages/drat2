## ---- setup, echo = FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, fig.keep = "none")

## -----------------------------------------------------------------------------
vignette(package = "knitr")   

## ---- , message=FALSE---------------------------------------------------------
browseVignettes(package = "knitr")

## ---- eval=FALSE, echo=c(1:4,6,8:17)------------------------------------------
#  ---
#  title: "My very first vignette"
#  author: "Colin Gillespie and Robin Lovelace"
#  output: rmarkdown::html_vignette
#  #nolint start
#  vignette: >
#  #nolint end
#     %\VignetteIndexEntry{My very first vignette}
#     %\VignetteEngine{knitr::rmarkdown}
#     %\VignetteEncoding{UTF-8}
#  ---
#  
#  ## My first package
#  
#  This is my **first** package vignette. I can
#  include mathematics, such as $x^2$. R code is
#  also nicely formatted and displayed.

## ---- eval=FALSE--------------------------------------------------------------
#  install.packages("pkg_1.0.tar.gz", repos=NULL,
#  type="source")

## ---- eval=FALSE, tidy=FALSE--------------------------------------------------
#  library("pkg")
#  ?pkg

