# jrShiny 1.3.0 _2020-12-18_

  * Add NEWS.md
  * Fix lint errors
  * Add libgit2-dev dep to travis.yml
  * ALLOWED_NOTES=3 (from 1) in .travis.yml
