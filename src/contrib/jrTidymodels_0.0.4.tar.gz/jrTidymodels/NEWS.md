# jrTidymodels 0.0.4 _2020-09-17_
  * Add caret pkg to Imports

# jrTidymodels 0.0.3 _2020-09-17_
  * Add mixture_example data
  * Add boundary_plot.R
  * Add mixture_example.R
  * Update Dockerfile

# jrTidymodels 0.0.2 _2020-09-16_
  * Add tibble pkg to Imports

# jrTidymodels 0.0.1 _2020-09-16_
  * Initial pkg template
  * Add NEWS.md
