#' @rdname get_config
#' @export
get_repo_language = function() {
  con = get_config()
  lan = con$language
  if (is.null(lan)) stop("Set language in config")
  tolower(lan)
}

get_project_name = function() {
  proj_name = system("git remote -v | head -n1 | awk '{print $2}' | sed 's/.*\\///' | sed 's/\\.git//'", #nolint
                     intern = TRUE) #nolint

  gsub("_notes", "", proj_name)
}

#' @rdname get_config
#' @param dir Location to start looking
#' @export
get_root_dir = function(dir = ".") {
  if ("config.yml" %in% list.files(path = dir, all.files = TRUE)) {
    return(normalizePath(dir))
  }
  get_root_dir(dir = file.path("..", dir))
}

# The config file uses a variety of NULL/no/false/etc
get_config_logical = function(entry = NULL, default = FALSE) {
  if (is.null(entry)) return(default)
  if (entry == "no" || isFALSE(FALSE) || entry == "false") return(FALSE)
  return(TRUE)
}

#' Get Config file
#'
#' Extract config file.
#' @export
get_config = function() {
  path = get_root_dir()
  config = yaml::read_yaml(file.path(path, "config.yml"),
                           eval.expr = TRUE)

  config$rss = get_config_logical(config$rss, default = FALSE)
  config$lintr = get_config_logical(config$lintr, default = TRUE)
  config$vignettes = get_config_logical(config$vignettes, default = TRUE)
  config$cores = ifelse(is.null(config$cores), 1, config$cores)
  config$notes$advert = ifelse(is.null(config$notes$advert), "advert", config$notes$advert)

  return(config)
}
