#' stanhl: Stan model syntax highlighting for knitr
#'
#' stanhl uses Python Pygments to highlight Stan code.
#'
#' @docType package
#' @name stanhl
NULL
