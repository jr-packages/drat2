# jrRSConnect

The goal of jrRSConnect is to learn how to use RStudio Connect effectively

## Installation

You can install jrRSConnect from github with:

``` r 
install.packages("devtools")
devtools::install_github("jr-packages/jrRSConnect")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```
