# jrPresentation2 0.3.0 _2021-07-07_
  * Added mandy to authors and twitter handle
  * Changed from jrNotes to jrNotes2 in `create_final.R`

# jrPresentation2 0.2.9 _2021-06-28_
  * Update connect server

# jrPresentation2 0.2.8 _2021-05-22_
  * Pin {countdown} to 0.3.5

# jrPresentation2 0.2.7 _2021-05-08_
  * Refactor `get_author.R`
  * Give known users _without_ a twitter handle the JR handle

# jrPresentation2 0.2.6 _2020-01-12_
  * Fix provisioning of venv

# jrPresentation2 0.2.5 _2020-01-12_
  * Update twitter handle

# jrPresentation2 0.2.4 _2020-12-28_
  * Moving to jrNotes2

# jrPresentation 0.2.3 _2020-12-17_
  * Remove cross-references from labels before slides title check

# jrPresentation 0.2.2 _2020-12-17_
  * Create function `create_final_python()` which ensures that a python
    virtualenv is active for the checks to run.

# jrPresentation 0.2.1 _2020-12-14_
  * Introduce `render()` function, a `jrPresentation` equivalent of
    `jrNotes::render()`.

# jrPresentation 0.2.0 _2020-09-24_
  * Change regex pattern to remove labels in `check_slides_titles()`
  * ALLOWED_NOTES=1 (All declared Imports)
  * Fix lintr errors
  * Create symlink to graphics path
  * Check that titles in notes and slides match
  * Use make final

# Version 0.1.*
  * Add countdown suggests
  * Add code lint
  * Build slides via a function so we can skip shiny slides
  * Add lint_slides
  * Copyright year now dynamic
  * Hide warnings from clean_up site
  * Adding connect functionality
  * Create example slides in the same directory
  * Add optional page numbers
  * Add optional url link to sides
  * Add background_size option to add_border
  * Update copyright year
  * Add background_image option to border
  * New add_class function for setting inverse, middle, center options
  * Use CSS to remove slide number
  * Update .gitignore
  * Create standard .gitignore & Makefile
  * Add welcome slide
