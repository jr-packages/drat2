## ----echo=FALSE---------------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)
# gets rid of all the echo = echo, results = results
# also makes it easier to be flexible about what shows where

## ---- eval=FALSE--------------------------------------------------------------
#  days = c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
#  for (day in days) {
#    message(day)
#  }

## -----------------------------------------------------------------------------
# The output will remain the same as the iterator, which acts as a placeholder for the
# iterator values in the vector, days, is being kept consistent throughout the body of the
# for loop.

## ----echo=TRUE----------------------------------------------------------------
library("tibble")
dd = tibble(x = rnorm(10),
            y = rnorm(10),
            z = rnorm(10))

max_cols = numeric(ncol(dd))

for (i in seq_along(dd)) {
  max_cols[i] = max(dd[[i]])
}
max_cols


## -----------------------------------------------------------------------------
means = numeric(ncol(dd))
sds = numeric(ncol(dd))

for (i in seq_along(dd)) {
  means[i] = mean(dd[[i]])
  sds[i] = sd(dd[[i]])
}

## ----eval=FALSE, echo=TRUE----------------------------------------------------
#  vignette("solutions1", package = "jrProgramming")

