library("testthat")
library("jrNotes")

test_check("jrNotes")
