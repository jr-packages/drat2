# jrBestPractices 0.0.1 _2021-03-22_

  * Update: Package title must match course
