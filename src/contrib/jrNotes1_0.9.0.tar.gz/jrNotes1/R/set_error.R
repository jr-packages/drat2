# .jrNotes1 is a hidden environment
# Setting error to be TRUE allows the check_* function to delay
# the stop() call to the end of all checks
set_error = function(origin = NULL) {
  .jrNotes1$error = TRUE
  .jrNotes1$error_funs = c(.jrNotes1$error_funs, origin)
  .jrNotes1$error_funs = unique(.jrNotes1$error_funs)
  return(invisible(NULL))
}
