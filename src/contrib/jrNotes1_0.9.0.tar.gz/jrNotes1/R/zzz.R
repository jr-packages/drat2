.jrNotes1 = new.env()
.jrNotes1$error = FALSE
.jrNotes1$error_funs = NULL
