library("testthat")
library("jrNotes1")

test_check("jrNotes1")
