#' @rdname apt_update
#' @export
pip_install = function() {
  cli::cli_h2("Installing pip packages")
  pip_pkgs = yaml::read_yaml("config.yml")$pip_pkgs
  if (is.null(pip_pkgs)) {
    cli::cli_alert_info("No pip pkgs found")
    return(invisible(NULL))
  }

  system2("pip3", c("install", pip_pkgs))
  return(invisible(pip_pkgs))
}
