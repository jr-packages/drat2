## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, collapse = TRUE, results = "hide", fig.keep = "none")

## ---- echo = TRUE-------------------------------------------------------------
library("tidyverse")
data(files, package = "jrTidyverse2")

