# jrGgplot2 0.2.2 _2021-09-17_
  * Update pkg title

# jrGgplot2 0.2.1 _2021-04-27_
  * Add rmarkdown to SUGGESTS

# jrGgplot2 0.2.0 _2021-02-04_
  * Rename Beauty gender variable to sex
  * Add {gghighlight} to DESCRIPTION

# jrGgplot2 0.1.* _2020-09-18_
  * Change pkg title
  * Add NEWS.md
  * Fix lintr errors
