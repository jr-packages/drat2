# jrAdvanced 0.1.2 _2020-11-26_
    * Add docker file, News and update title in line with other packages
