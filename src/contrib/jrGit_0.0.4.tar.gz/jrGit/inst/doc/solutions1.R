## ----echo=FALSE---------------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "show", echo = TRUE)

