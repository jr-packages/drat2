## ----echo=FALSE---------------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "show", echo = TRUE)

## ---- tidy=TRUE,                                   tidy.opts=list(width.cutoff=50)----
# origin is the general word used to describe the
# upstream remote repository that has been synced
# with your local copy

## ---- tidy=TRUE,                                   tidy.opts=list(width.cutoff=50)----
# This forces the upstream dev remote branch to
# be formed under the same name as your local
# branch

## ---- tidy=TRUE,                                   tidy.opts=list(width.cutoff=50)----
# No - we have not yet made any changes or added
# any files to the files already nested within
# the dev branch. We can see this visually by
# observing the fact that there are no files
# ready to be staged for a commit. 

## ---- tidy=TRUE,                                   tidy.opts=list(width.cutoff=50)----
# We are staging the file in preperation for it
# to be commited. The M symbol stands for
# "Modified". This is telling is that we have
# changed a file that is already stored in the
# project.

## ---- tidy=TRUE,                                   tidy.opts=list(width.cutoff=50)----
# Commit messages are important when working
# collaboratively because it gives collaborators
# a clear understanding of the updates you have
# made to a project. It also serves as a reminder
# to yourself for future reference.

## ---- tidy=TRUE,                                   tidy.opts=list(width.cutoff=50)----
# We have made commit objects in our other/dev
# branch, which is independent of our master
# branch

## ---- tidy=TRUE,                                   tidy.opts=list(width.cutoff=50)----
# A branch with the same name (dev) as your new
# branch will have been created in the remote
# repository. This is because we kept the box
# next to "Sync branch with remote" ticked.

