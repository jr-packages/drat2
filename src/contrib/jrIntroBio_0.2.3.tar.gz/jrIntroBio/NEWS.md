# jrIntroBio 0.2.3 _2021-06-28_
  * Tidy description

# jrIntroBio 0.2.2 _2021-01-02_

  * Initialise
