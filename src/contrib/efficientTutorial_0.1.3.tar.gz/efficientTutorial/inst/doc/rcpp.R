## ---- message=FALSE-----------------------------------------------------------
library("Rcpp")

## ----eval=FALSE---------------------------------------------------------------
#  cppFunction("
#    double add_c(double x, double y) {
#      double value = x + y;
#      return value;
#    }
#  ")

## ---- echo=-1-----------------------------------------------------------------
my_mean = mean
# Very bad sd function
my_var = function(x) {
  n = length(x)
  m = my_mean(x)
  total = 0
  for (i in 1:n) {
    total = total + (x[i] - m)^2
  }
  total / (n - 1)
}

## -----------------------------------------------------------------------------
set.seed(1)
x = rnorm(10)
my_var(x)
var(x)

