## -----------------------------------------------------------------------------
library("efficientTutorial")
snakes_ladders()

## ----eval = FALSE-------------------------------------------------------------
#  n = 10
#  results = numeric(n)
#  for (i in 1:n) {
#    results[i] = snakes_ladders()
#  }

## ---- eval=FALSE--------------------------------------------------------------
#  results = sapply(1:n, function(i) snakes_ladders())

## ----echo=FALSE, eval=FALSE---------------------------------------------------
#  library("parallel")
#  cl  = makeCluster(2)
#  parSapply(cl, 1:4, snakes_ladders)
#  stopCluster(cl)

