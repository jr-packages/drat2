## ----practical1, echo=-2------------------------------------------------------
N = 1e5
N = 1e4
m = as.data.frame(matrix(runif(N), ncol = 1000))
write.csv(m, file = "example.csv", row.names = FALSE)

## -----------------------------------------------------------------------------
dd = read.csv("example.csv")

## ----eval=TRUE, results="hide"------------------------------------------------
system.time(read.csv("example.csv"))

## ----cache=TRUE,results='hide', tidy=FALSE------------------------------------
read.csv(file = "example.csv", colClasses = rep("numeric", 1000))

## ----cache=TRUE, results="hide"-----------------------------------------------
saveRDS(m, file = "example.RData")
readRDS(file = "example.RData")

## -----------------------------------------------------------------------------
##For fast computers
#d_m = matrix(1:1000000, ncol=1000)
##Slower computers
d_m = matrix(1:10000, ncol = 100)
dim(d_m)

## ---- cache = FALSE-----------------------------------------------------------
d_df = as.data.frame(d_m)
colnames(d_df) = paste0("c", seq_along(d_df))

## ----results='hide', tidy=FALSE-----------------------------------------------
microbenchmark::microbenchmark(times = 1000, unit = "ms", # milliseconds
      d_m[1, ], d_df[1, ], d_m[, 1], d_df[, 1])

## ----results='hide'-----------------------------------------------------------
d_df$c10
d_df[, 10]
d_df[, "c10"]
d_df[, colnames(d_df) == "c10"]

