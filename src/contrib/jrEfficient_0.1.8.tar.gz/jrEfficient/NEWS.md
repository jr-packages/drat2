# jrEfficient 0.1.8 _2020-09-17_

  * Bump ggbeeswarm, ggplot2, tidyr from Suggests to Imports

# jrEfficient 0.1.7 _2020-09-11_

  * Update course dependencies
  * Remove generated files

# jrEfficient 0.1.6 _2020-09-02_

  * Update course package name to match notes
  * Add NEWS.md
