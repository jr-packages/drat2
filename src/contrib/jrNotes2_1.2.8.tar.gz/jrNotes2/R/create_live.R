#' Create scripts for online training
#'
#' Creates a vm_scripts folder
#' Creates exercises.(R|ipynb) and solutions.(R|ipynb) from master_exercises.(R|Rmd)
#' Creates tutor.(R|ipynb) and tutor_blank.(R|ipynb) from master_tutor.(R|Rmd)
#' Zips VM folder ready to be exposed as an artefact
#' @importFrom fs dir_ls file_copy
#' @importFrom stringr str_to_lower str_subset str_replace
#' @param live_path Path to the live directory. If NULL, uses get_root_dir()/live
#' @param notes_path Path to the notes directory. If NULL, uses get_root_dir()/notes
#' @param add_notes Whether to copy notes pdf into vm_scripts folder
#' @export
create_live_scripts = function(live_path = NULL, notes_path = NULL, add_notes = TRUE) {

  if (is.null(live_path)) live_path = file.path(get_root_dir(), "live")
  if (is.null(notes_path)) notes_path = file.path(get_root_dir(), "notes")
  if (!fs::dir_exists(live_path)) return(invisible(NULL))

  msg_start("Creating scripts for VM...")

  # Create scripts dir and clean up past
  scripts_dir = file.path(live_path, c("vm_scripts", "tutor_scripts"))
  fs::dir_create(scripts_dir)
  fs::file_delete(fs::dir_ls(scripts_dir))

  chapters = list.files(path = live_path, pattern = "chapter")
  if (get_repo_language() == "python") {
    create_live_python(live_path, chapters)
  } else {
    create_live_r(live_path, chapters)
  }

  # Zip the vm_scripts folder
  zip_scripts(live_path, notes_path, add_notes = add_notes)

  # Clean up
  fs::dir_delete(scripts_dir)
  msg_success("Live scripts created and zipped")
}

#' Zips VM folder ready to be exposed as an artefact
#'
#' @importFrom fs file_copy
#' @importFrom zip zipr
#' @param live_path The path to the live directory
#' @param notes_path Path to the notes directory
#' @param add_notes Whether to copy notes pdf into vm_scripts folder
zip_scripts = function(live_path, notes_path, add_notes) {
  # Zip folder
  msg_start("Zipping scripts...")
  scripts_dir = file.path(live_path, c("vm_scripts", "tutor_scripts"))
  fs::file_delete(fs::dir_ls(scripts_dir, glob = "*.Rmd$", recurse = 1))

  # Copy notes into vm_scripts.zip (if desired)
  if (isTRUE(add_notes)) {
    fs::file_copy(glue("{notes_path}/index.pdf"),
                  glue("{live_path}/vm_scripts/notes.pdf"),
                  overwrite = TRUE)
  }

  zip::zipr(
    zipfile = file.path(live_path, "tutor_scripts.zip"),
    files = file.path(live_path, "tutor_scripts")
  )
  zip::zipr(
    zipfile = file.path(live_path, "vm_scripts.zip"),
    files = file.path(live_path, "vm_scripts")
  )
}

#' Create scripts r
#'
#' Creates a vm_scripts folder
#' Creates exercises.R and solutions.R from master_exercises.R
#' Creates tutor.R and tutor_blank.R from master_tutor.R
#'
#' @importFrom fs dir_ls file_copy
#' @importFrom stringr str_to_lower str_subset str_replace
#' @param live_path The path to the live directory
#' @param chapters The path to the chapters to create
create_live_r = function(live_path, chapters) {
  # Set up file extension
  course = str_to_lower(get_project_name())
  if (course == "jrrmarkdown") {
    ext = "Rmd"
  } else {
    ext = "R"
  }
  # Create folders
  fs::dir_create(file.path(live_path, "vm_scripts", chapters))
  for (chapter in chapters) {
    # Check for images
    files = list.files(glue("{live_path}/{chapter}"), full.names = TRUE)
    imgs = str_subset(files, "\\.png$")

    # Copy images
    if (length(imgs) > 0) {
      fs::file_copy(
        path = imgs,
        new_path = str_replace(imgs, live_path, glue("{live_path}/vm_scripts")),
        overwrite = TRUE
      )
    }

    # Create tutor scripts
    if (file.exists(glue("{live_path}/{chapter}/master_tutor.{ext}"))) {
      # Create tutor_scripts/chapterX.{ext}
      system2(
        "sed",
        args = c(
          shQuote("/^#>.*/d"),
          glue("{live_path}/{chapter}/master_tutor.{ext}")
        ),
        stdout = glue("{live_path}/tutor_scripts/{chapter}.{ext}")
      )

      # Create vm_scripts/chapterX/tutor.{ext}
      system2(
        "sed",
        args = c(
          shQuote("s/^#> //"),
          glue("{live_path}/{chapter}/master_tutor.{ext}")
        ),
        stdout = glue("{live_path}/vm_scripts/{chapter}/tutor.{ext}")
      )
    }

    # Create exercises and solutions
    master_exercises_ext = glue("{live_path}/{chapter}/master_exercises.{ext}")
    if (file.exists(master_exercises_ext)) {
      # Create exercises_original.{ext}
      ## Delete lines starting with #>
      ## Keep lines starting with #<
      system2("sed",
              args = c(shQuote("/^#>.*/d ; s/^#< //"), master_exercises_ext),
              stdout = glue(
                "{live_path}/vm_scripts/{chapter}/exercises_original.{ext}"
              )
      )

      # Create exercises.{ext}
      fs::file_copy(
        path = glue(
          "{live_path}/vm_scripts/{chapter}/exercises_original.{ext}"
        ),
        new_path = glue("{live_path}/vm_scripts/{chapter}/exercises.{ext}"),
        overwrite = TRUE
      )

      # Create solutions.{ext}
      ## Delete lines starting with #<
      ## Keep lines starting with #>
      system2("sed",
              args = c(shQuote("/^#<.*/d ; s/^#> //"), master_exercises_ext),
              stdout = glue("{live_path}/vm_scripts/{chapter}/solutions.{ext}")
      )
    }
  }
}

#' Create live python
#'
#' Creates a vm_scripts folder
#' Creates exercises.ipynb and solutions.ipynb from master_exercises.Rmd
#' Creates tutor.ipynb and a blank one from master_tutor.Rmd
#'
#' @importFrom fs dir_ls file_copy
#' @importFrom glue glue
#' @param live_path The location to the live directory
#' @param chapters The path to the chapters to create
create_live_python = function(live_path, chapters) {
  for (chapter in chapters) {
    # Create folder
    dir.create(glue::glue("{live_path}/vm_scripts/{chapter}", showWarnings = FALSE))

    # Create tutor scripts
    if (file.exists(glue::glue("{live_path}/{chapter}/master_tutor.Rmd"))) {
      # Create tutor_scripts/chapterX.py
      system2(
        "sed",
        args = c(
          shQuote("/^#>.*/d"),
          glue::glue("{live_path}/{chapter}/master_tutor.Rmd")
        ),
        stdout = glue::glue("{live_path}/tutor_scripts/{chapter}.Rmd")
      )
      # convert tutor scripts to notebooks
      system2("jupytext", c(
        "--to",
        "notebook",
        glue::glue("{live_path}/tutor_scripts/{chapter}.Rmd")
      ))

      # Create vm_scripts/chapterX/tutor.R
      system2(
        "sed",
        args = c(
          shQuote("s/^#> //"),
          glue::glue("{live_path}/{chapter}/master_tutor.Rmd")
        ),
        stdout = glue::glue("{live_path}/vm_scripts/{chapter}/tutor.Rmd")
      )

      # convert student scripts to notebooks
      system2("jupytext",
              c(
                "--to",
                "notebook",
                glue::glue("{live_path}/vm_scripts/{chapter}/tutor.Rmd")
              ))
    }

    # Create exercises and solutions
    if (file.exists(glue::glue("{live_path}/{chapter}/master_exercises.Rmd"))) {
      # Create exercises_original.R
      system2(
        "sed",
        args = c(
          shQuote("/^#>.*/d"),
          glue::glue("{live_path}/{chapter}/master_exercises.Rmd")
        ),
        stdout = glue::glue(
          "{live_path}/vm_scripts/{chapter}/exercises_original.Rmd"
        )
      )
      system2("jupytext",
              c(
                "--to",
                "notebook",
                glue::glue(
                  "{live_path}/vm_scripts/{chapter}/exercises_original.Rmd"
                )
              ))

      # Create exercises.R
      fs::file_copy(
        path = glue::glue(
          "{live_path}/vm_scripts/{chapter}/exercises_original.ipynb"
        ),
        new_path = glue::glue("{live_path}/vm_scripts/{chapter}/exercises.ipynb"),
        overwrite = TRUE
      )

      # Create solutions.R
      system2(
        "sed",
        args = c(
          shQuote("s/^#> //"),
          glue::glue("{live_path}/{chapter}/master_exercises.Rmd")
        ),
        stdout = glue::glue("{live_path}/vm_scripts/{chapter}/solutions.Rmd")
      )

      system2("jupytext",
              c(
                "--to",
                "notebook",
                glue::glue("{live_path}/vm_scripts/{chapter}/solutions.Rmd")
              ))

    }
  }
}
