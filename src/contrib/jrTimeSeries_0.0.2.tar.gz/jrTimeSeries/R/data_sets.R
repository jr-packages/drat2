#' Admissions raw data
#'
#' Monthly activity data relating to elective and non-elective inpatient
#' hospital admissions for NHS England. This data set is a tibble.
#' The tsibble version is available at \code{data(admissions)}.
#'
#' @format A tibble with three variables: \code{date}, \code{admission_type},
#' and \code{n}.
#' @name admissions_raw
#' @docType data
#' @usage data(admissions_raw)
#' @source \url{https://www.england.nhs.uk/statistics/statistical-work-areas/hospital-activity/monthly-hospital-activity/mar-data/} #nolint
#' @keywords datasets
#' @examples
#' data(admissions_raw)
NULL

#' Admissions data
#' 
#' #' Monthly activity data relating to elective and non-elective inpatient
#' hospital admissions for NHS England. 
#'
#' @name admissions
#' @docType data
#' @format A tsibble with three variables: \code{date}, \code{admission_type},
#' and \code{n}.
#' @usage data(admissions)
#' @keywords datasets
#' @source \url{https://www.england.nhs.uk/statistics/statistical-work-areas/hospital-activity/monthly-hospital-activity/mar-data/} #nolint
#' @examples
#' data(admissions)
NULL


#' Durham data
#'
#' A data set containing the mean maximum daily temperature for Durham, 
#' observed monthly from Jan 2000 to Nov 2020.
#' @name durham
#' @docType data
#' @format  A tsibble with two variables: the index column \code{ym} and
#'  the mean maximum daily temperature \code{tmax}.
#' @usage data(durham)
#' @source \url{https://www.metoffice.gov.uk/pub/data/weather/uk/climate/stationdata/durhamdata.txt} #nolint
#' @keywords datasets
#' @examples
#' data(durham)
NULL

#' Visits abroad
#'
#' A data set containing the visits from the U.K to overseas. The series is
#' quarterly and is collected from 1980 Q1 to 2020 Q1.
#' @name visits_abroad
#' @docType data
#' @format  A tsibble with two variables: the index column (\code{quarter}) and
#'  the number of visits from the U.K overseas (\code{visits}).
#' @usage data(visits_abroad)
#' @source \url{https://www.ons.gov.uk/peoplepopulationandcommunity/leisureandtourism/timeseries/gmaf/ott} #nolint
#' @keywords datasets
#' @examples
#' data(visits_abroad)
NULL

#' Homeless
#'
#' A data set containing decisions on whether a household is homeless and in
#' priority need. The series is quarterly and is collected from 1998 Q1 to 
#' 2018 Q1. The type refers the the decision made. The options are "Accepted",
#' "Rejected intentionally homeless", "Rejected not homeless" or
#' "Rejected not in priority need".
#' @name homeless
#' @docType data
#' @format  A tsibble with three variables: the index column (\code{Quarter}),
#' the homelessness decision \code{Type} and the number of households
#' (\code{Households}).
#' @usage data(homeless)
#' @source \url{https://opendatacommunities.org/data/homelessness/homelessness-decisions/decisions} #nolint
#' @keywords datasets
#' @examples
#' data(homeless)
NULL


#' Rail
#'
#' A data set containing the number of passenger kilometres travelled (billions)
#' in Great Britain. The series is quarterly and is collected from 1994 Q2 to
#' 2020 Q1. The type refers the the type of franchise. The options are 
#' "Franchised long distance operators", "Franchised London and South East 
#'  operators" and	"Franchised regional operators".
#' @name rail
#' @docType data
#' @format  A tsibble with three variables: the index column (\code{Quarter}),
#' the homelessness decision \code{Type} and passenger kilometres travelled 
#' (billions) (\code{Kilometers}).
#' @usage data(rail)
#' @source \url{https://dataportal.orr.gov.uk/statistics/usage/passenger-rail-usage/table-1231-passenger-kilometres-by-sector/} #nolint
#' @keywords rail
#' @examples
#' data(rail)
NULL


#' Rail (raw)
#'
#' A data set containing the number of passenger kilometres travelled (billions)
#'  in Great Britain.
#' The series is quarterly and is collected from 1994 Q2 to 2020 Q1.
#' The type refers the the type of franchise. The options are 
#' "Franchised long distance operators","Franchised London and South 
#' East operators" and	"Franchised regional operators"
#' This data set is a tibble. The tsibble version is available at
#'  \code{data(rail)}.
#' 
#' @name rail_raw
#' @docType data
#' @format  A tibble with three variables: the index column (\code{Quarter}),
#' the homelessness decision \code{Type} and passenger kilometres travelled 
#' (billions) (\code{Kilometers}).
#' @usage data(rail)
#' @source \url{https://dataportal.orr.gov.uk/statistics/usage/passenger-rail-usage/table-1231-passenger-kilometres-by-sector/} #nolint
#' @keywords rail_raw
#' @examples
#' data(rail_raw)
NULL
