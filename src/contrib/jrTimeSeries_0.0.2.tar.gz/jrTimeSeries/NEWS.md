# jrTimeSeries 0.0.2 _2021-02-10_
  * Change pkg title

# jrTimeSeries 0.0.1 _2020-12-02_
  * Initial pkg template
