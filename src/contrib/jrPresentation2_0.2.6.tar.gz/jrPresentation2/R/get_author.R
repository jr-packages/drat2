#' Presentation author and twitter handle
#'
#' Returns a nicely formatted name and twitter handle.
#' @param user By default grabs the system name and matches user.
#' @examples
#' get_author(user = "ncsg3")
#' @export
get_author = function(user = NULL) {

  authors = list(colin =
                   "Colin Gillespie ([\\@csgillespie](https://twitter.com/csgillespie))",
                 jamie =
                   "Jamie Owen ([\\@jamieRowen](https://twitter.com/jamieRowen))",
                 theo =
                   "Theo Roe ([\\@theoJRivers1](https://twitter.com/theoJRivers1))",
                 rhian =
                   "Rhian Davies ([\\@statsRhian](https://twitter.com/statsrhian))",
                 john =
                   "John McIntyre",
                 jack =
                   "Jack Walton"
  )

  if (is.null(user)) user = Sys.info()["user"]

  if (user == "ncsg3") user = "colin"

  if (user %in% names(authors)) {
    authors[user]
  } else {
    "Jumping Rivers ([\\@jumping_uk](https://twitter.com/jumping_uk))"
  }
}
