# jrEfficient 0.2.0 _2021-04-27_

  * Add {rmarkdown} to SUGGESTS

# jrEfficient 0.1.* _2021-04-27_
  * Update: R >= 3.5.0
  * Bump ggbeeswarm, ggplot2, tidyr from Suggests to Imports
  * Update course dependencies
  * Remove generated files
  * Update course package name to match notes










