# jrBig 0.1.5 _2021-04-28_
  * ggplot2 to Suggests
  * Add missing deps

# jrBig 0.1.4 _2021-01-03_
  * Initialise
