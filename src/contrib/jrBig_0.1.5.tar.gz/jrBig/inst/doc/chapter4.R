## ----eval=FALSE---------------------------------------------------------------
#  library("sparklyr")
#  sc = spark_connect(master = "local")

## ----eval=FALSE---------------------------------------------------------------
#  library("dplyr")

## ----eval=FALSE---------------------------------------------------------------
#  ?nycflights13::flights

## ----eval=FALSE---------------------------------------------------------------
#  flights_tbl = copy_to(sc, nycflights13::flights, "flights")

## ----eval=FALSE---------------------------------------------------------------
#  flights_tbl %>% filter(air_time > 10 * 60)

## ----eval=FALSE---------------------------------------------------------------
#  delay = flights_tbl %>%
#    group_by(day) %>%
#    summarise(delay = mean(arr_delay))

## ----eval=FALSE---------------------------------------------------------------
#  delay_collect = delay %>% collect()

## ----eval=FALSE---------------------------------------------------------------
#  library(ggplot2)
#  ## Why does delay not work below?
#  ggplot(delay_collect, aes(day, delay)) +
#    geom_point() +
#    geom_smooth()

## ----eval=FALSE, echo=FALSE---------------------------------------------------
#  library(lubridate)
#  delay$wday = wday(dmy(paste(delay$day, delay$month, delay$year)),
#    label = TRUE)

