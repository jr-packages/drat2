# jrBig
[![Build Status](https://api.travis-ci.org/jr-packages/jrBig.png?branch=master)](https://travis-ci.org/jr-packages/jrBig)

Course material for the [R for big data](www.jumpingrivers.com) course. 
