# .jrnotes is a hidden environment
# Setting error to be TRUE allows the check_* function to delay
# the stop() call to the end of all checks
set_error = function() {
  .jrnotes$error = TRUE
}
