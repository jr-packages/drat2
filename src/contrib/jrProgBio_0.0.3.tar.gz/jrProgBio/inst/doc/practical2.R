## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ----echo=TRUE----------------------------------------------------------------
n = 5
sequence = function() {
  bases = c("C", "G", "A", "T")
  n = 10
  paste(sample(bases, n, TRUE), collapse = "")
}
sequence()

## -----------------------------------------------------------------------------
## sequence uses the local variable n

## -----------------------------------------------------------------------------
sequence = function(n) {
  bases = c("C", "G", "A", "T")
  paste(sample(bases, n, TRUE), collapse = "")
}
sequence(5)

## ----echo=TRUE----------------------------------------------------------------
one = function(x = 10) {
  return(x)
}

two = function(x) {
  return(x)
}

## ----echo=TRUE----------------------------------------------------------------
one()

## ----eval=FALSE, echo=TRUE----------------------------------------------------
#  two()

## -----------------------------------------------------------------------------
## two() expects an argument x, but
## we haven't given one and there is
## no default.

## -----------------------------------------------------------------------------
sequence = function(n = 10) {
  bases = c("C", "G", "A", "T")
  paste(sample(bases, n, TRUE), collapse = "")
}
sequence()

## ---- echo=TRUE---------------------------------------------------------------
library(stringr)
# create the sequence
s = sequence()

# establish indeces of the first and last base in the codon
offset = 0
start = seq(1 + offset, str_length(s), by = 3)
end = start + 2

# retrieve the codons
str_sub(s, start, end)

## -----------------------------------------------------------------------------
codons = function(sequence) {
  offset = 0
  start = seq(1 + offset, nchar(sequence), by = 3)
  end = start + 2
  str_sub(sequence, start, end)
}

## -----------------------------------------------------------------------------
codons = function(sequence, offset = 0) {
  start = seq(1 + offset, nchar(sequence), by = 3)
  end = start + 2
  str_sub(sequence, start, end)
}

## -----------------------------------------------------------------------------
codons = function(sequence, offset = 0, length = 3) {
  start = seq(1 + offset, nchar(sequence), by = length)
  end = start + length - 1
  str_sub(sequence, start, end)
}

## ----eval=FALSE, echo=TRUE----------------------------------------------------
#  vignette("solutions2", package = "jrProgBio")

