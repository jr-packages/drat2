# jrRmd 0.3.8 _2021-07-23_
  * Trivial formatting: `<-` to `=`

# jrRmd 0.3.7 _2021-06-25_
  * Add `mental_health` data

# jrRmd 0.3.6 _2020-09-28_
  * Admin: Updated package title
