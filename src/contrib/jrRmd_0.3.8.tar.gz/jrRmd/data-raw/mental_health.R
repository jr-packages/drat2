library("readr")
library("dplyr")
mental_health = read_csv("data-raw/survey.csv")
mental_health = mental_health %>%
  select(2:18, -c(seek_help, state)) %>%
  rename(sex = Gender, age = Age,
         country = Country, employer_benefits = benefits) %>%
  mutate(sex = case_when(sex %in% c("M", "m", "Male", "male",
                                    "maile", "Mal", "Make", "Man",
                                    "msle", "Mail", "Malr", "Cis Male",
                                    "cis male", "Cis Man") ~ "Male",
                        sex %in% c("f", "F", "female", "Female",
                                   "Woman", "Femake", "WOMAN",
                                   "femail", "Cis Female",
                                   "Female (cis)", "cis-female/femme")
                        ~ "Female")) %>%
  tidyr::drop_na(sex)
usethis::use_data(mental_health, overwrite = TRUE, compress = "xz")
