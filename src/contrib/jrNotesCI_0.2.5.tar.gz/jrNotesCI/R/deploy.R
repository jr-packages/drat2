deploy_to_drat = function() {
  any_r_pkgs = FALSE
  dir = Sys.getenv("CI_PROJECT_DIR", ".")

  pkgs = list.files(path = file.path(dir, "r_pkgs"))
  for (pkg in pkgs) {
    if (file.exists(file.path(dir, "r_pkgs", pkg, "DESCRIPTION"))) {
      system2("R", args = c("CMD", "build", file.path(dir, "r_pkgs", pkg)))
      any_r_pkgs = TRUE
    }
  }
  ## This package is special
  if (file.exists(file.path(dir, "jrNotesCI"))) {
    system2("R", args = c("CMD", "build", file.path(dir, "jrNotesCI")))
    any_r_pkgs = TRUE
  }

  if (isTRUE(any_r_pkgs)) {
    dir.create(file.path(dir, "r_pkgs_tar"))
    tars = list.files(dir, pattern = ".tar.gz", full.names = TRUE)
    file.copy(tars, file.path(dir, "r_pkgs_tar"))
    file.remove(tars)
    fname = system.file("deploy-drat.sh", package = "jrNotesCI")
    system2("bash", fname)
  }

}

#' Deploy functions to drat
#' Eventually add pypi
#' @export
deploy = function() {
  deploy_to_drat()
}
