# jrPredictive 1.2.1 _2020-10-07_
  * Update: Package title must match course

# jrPredictive 1.2.0 _2020-10-07_
  * Update: package title
