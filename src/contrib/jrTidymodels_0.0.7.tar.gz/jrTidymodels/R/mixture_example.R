#' The mixture example data set
#'
#' Mixture example data from the now archived ElemStatLearn package
#' @name mixture_example
#' @docType data
#' @examples
#' data(mixture_example)
NULL
