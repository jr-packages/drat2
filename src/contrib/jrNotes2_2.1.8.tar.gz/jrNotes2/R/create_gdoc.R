#' Read upcoming course details
#'
#' @importFrom yaml read_yaml
#' @rdname create_gdoc
read_upcoming = function() {
  yaml::read_yaml("upcoming_course.yml")
}

#' Fetch the Asana task specified in upcoming_course.yml
#'
#' @rdname create_gdoc
get_asana_task = function() {
  if (!requireNamespace("jrApiAsana")) {
    stop("You must install {jrApiAsana} to use this functionality")
  }
  asana_task_url = read_upcoming()$asana_task_url
  task_gid = utils::tail(strsplit(asana_task_url, "/")[[1]], n = 1)
  jrApiAsana::get_task(task_gid, as_tibble = FALSE)
}

#' Extract course information from Asana task specified in upcoming_course.yml
#'
#' @importFrom stringr str_extract str_match str_trim
#' @rdname create_gdoc
get_course_info = function() {

  task = get_asana_task()

  date = stringr::str_extract(task$name, "^\\d{4}-\\d{2}-\\d{2}")
  client_id = stringr::str_extract(task$name, "\\[\\w+\\]")
  client_name = stringr::str_match(task$projects[[1]]$name,
                                   "^\\[\\w+\\]\\s*(.*)\\(\\w*\\)")[, 2] %>%
                  stringr::str_trim()
  vm_url = task$custom_fields[[6]]$display_value

  list(date = date,
       client_id = client_id,
       client_name = client_name,
       vm_url = vm_url)
}

#' Construct filename for google doc
#'
#' @param course_info Named list containing course date and client id
#' @importFrom glue glue
#' @rdname create_gdoc
construct_gdoc_filename = function(course_info) {
  # Get course name from config
  course_name = get_config()$running

  # Construct filename from details and course name
  glue::glue("{course_info$date} {course_info$client_id} {course_name}")
}

#' Get id of client delivery folder, creating it if it doesn't exist
#'
#' @param course_info Named list containing course date and client id
#' @importFrom glue glue
#' @importFrom googledrive as_id drive_ls drive_mkdir
#' @rdname create_gdoc
get_client_dir_id = function(course_info) {

  # Location of client training delivery folder (from suffix in drive url)
  client_parent_id = googledrive::as_id("1efi9SnQ7e0LSPToJI3cmTw-Gy6ZseOV0")
  # List all existing client directories
  client_dirs = googledrive::drive_ls(client_parent_id, type = "folder")

  # Get name of client's directory from upcoming_course.yml
  client_dir = glue::glue("{course_info$client_id} {course_info$client_name}")

  # If client_dir exists then grab it, otherwise make it
  if (client_dir %in% client_dirs$name) {
    client_dir_id = client_dirs[client_dirs$name == client_dir, "id"][[1]]
  } else {
    client_dir_id = googledrive::drive_mkdir(client_dir, client_parent_id)$id
  }

  googledrive::as_id(client_dir_id)
}

#' Simple wrapper around rmarkdown::render()
#'
#' @importFrom rmarkdown render
#' @export
#' @rdname create_gdoc
render_docx = function() {
  provision_venv()
  course_info = get_course_info()
  extdata = read_upcoming()$extdata
  rmarkdown::render("index.Rmd",
                    output_format = "word_document",
                    params = list(asana = course_info, extdata = extdata))
}

#' Ensure that the file is being uploaded from a jr.com user
#'
#' @importFrom googledrive drive_auth drive_user
#' @rdname create_gdoc
check_google_user = function() {
  # Authenticate against google drive
  googledrive::drive_auth()
  # Get the user authenticated as
  user = googledrive::drive_user()

  if (!endsWith(user$emailAddress, "@jumpingrivers.com")) {
    stop("Must authenticate with a jumpingrivers.com email address.")
  }
}

#' Upload index.docx to google drive
#'
#' @param public boolean, whether to make the document writable by any with
#' link, defaults to TRUE
#' @importFrom googledrive drive_upload drive_share
#' @export
#' @rdname create_gdoc
upload_docx = function(public = TRUE) {
  # Check we are authenticated as as jr.com user
  check_google_user()

  course_info = get_course_info()
  filename = construct_gdoc_filename(course_info)
  client_dir = get_client_dir_id(course_info)

  upload = googledrive::drive_upload("index.docx",
                                     name = filename,
                                     overwrite = TRUE,
                                     type = "document",
                                     path = client_dir)

  # Set document to be writeable to anyone with the link (default)
  if (isTRUE(public)) {
    googledrive::drive_share(upload, role = "writer", type = "anyone")
  }

  web_link = upload$drive_resource[[1]]$webViewLink[1]
  message(glue::glue("\n\nDocument uploaded to: {web_link}"))
  return(invisible(web_link))
}

#' Make register for attendees
#'
#' @param names Vector containing names of attendees
#' @param num_attendees The number of course attendees. Only use this parameter
#' if you don't know the names of the attendees.
#' @param num_parts The number of parts which a course is divided into
#' @importFrom flextable flextable
#' @export
#' @rdname create_gdoc
make_register = function(names = NULL, num_attendees = NULL, num_parts = 2) {

  if (!is.null(num_attendees)) {
    names = rep("", length.out = num_attendees)
  }
  num_attendees = length(names)

  df = tibble(Name = sort(names)) %>%
         mutate(About = NA)

  col_names = paste("Part", seq_len(num_parts))
  df[seq_len(num_attendees), col_names] = NA

  df %>%
    flextable::flextable() %>%
    flextable::theme_box()
}

#' Make multiple choice ballot table for attendees
#'
#' @param question A multiple choice question to ask attendees
#' @param choices Answers for the attendees to choose from
#' @importFrom flextable flextable add_header_row theme_box align
#' @importFrom tibble tibble
#' @export
#' @rdname create_gdoc
make_ballot = function(question, choices) {
  df = tibble::tibble()
  df[1, choices] = NA

  df %>%
    flextable::flextable() %>%
    flextable::add_header_row(values = question,
                              colwidths = length(choices)) %>%
    flextable::theme_box() %>%
    flextable::align(align = "center", part = "all")
}
