# R for Data Science  [![Build Status](https://api.travis-ci.org/jr-packages/jrModelling.png?branch=master)](https://travis-ci.org/jr-packages/jrModelling)

Course material for the [R for Data Science](https://jumpingrivers.com) course.

