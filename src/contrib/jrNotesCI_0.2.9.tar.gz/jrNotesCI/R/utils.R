get_root_dir = function(dir = ".") {
  fname = file.path(dir, "config.yml")
  if (file.exists(fname)) {
    return(normalizePath(dir))
  }
  get_root_dir(dir = file.path("..", dir))
}
