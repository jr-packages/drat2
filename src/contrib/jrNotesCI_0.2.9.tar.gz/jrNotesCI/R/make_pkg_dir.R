#' Create pkg directory
#'
#' Create a package directory and add it to the the ~/.Renviron file
#' @param dir Default \code{NULL}, which corresponds to $CI_PROJECT_DIR/ci_r_pkgs
#' @export
create_pkg_dir = function(dir = NULL) {
  cli::cli_h2("Creating pkg dir")
  if (is.null(dir)) {
    dir = file.path(Sys.getenv("CI_PROJECT_DIR"), "ci_r_pkgs")
  }

  cli::cli_alert_info("Creating {dir}")
  dir.create(dir, showWarnings = FALSE)
  if (!file.exists("~/.Renviron")) file.create("~/.Renviron")

  cli::cli_alert_info("Updating Renviron")
  f = file("~/.Renviron", open = "a")
  on.exit(close(f))
  writeLines(paste0("R_LIBS=", dir), con = f)

  return(invisible(NULL))
}
