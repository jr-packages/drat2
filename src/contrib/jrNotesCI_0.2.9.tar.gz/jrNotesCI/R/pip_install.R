#' Install python packages listed in the config.yml
#'
#' Extract and install python pkgs listed in config.yml
#' @export
pip_install = function() {
  cli::cli_h2("Installing Python pkgs")
  root = get_root_dir()

  con = yaml::read_yaml(file.path(root, "config.yml"))
  python_pkgs = con$python_pkgs
  if (is.null(python_pkgs)) return(invisible(NULL))
  system2("python3", args = c("-m", "pip", "install", python_pkgs))
}
