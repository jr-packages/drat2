## ----echo=FALSE---------------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)
# gets rid of all the echo = echo, results = results
# also makes it easier to be flexible about what shows where

## ----results="hide", echo=TRUE------------------------------------------------
european_countries = c("England", "Germany", "France", "Switzerland",
                       "Spain", "Italy", "Boznia and Herzegovina",
                       "Croatia", "Montenegro", "Sweden")
for (i in european_countries) {
    message(paste("The country", i, "consists of", nchar(i), "characters."))
}

## -----------------------------------------------------------------------------
for (i in european_countries[9]) {
  message(paste("The country", i, "consists of", nchar(i),
              "characters."))
}

## -----------------------------------------------------------------------------
for (i in european_countries[1:5]) {
  message(paste("The country", i, "consists of", nchar(i),
              "characters."))
}

## -----------------------------------------------------------------------------
for (i in sort(european_countries)) {
  message(paste("The country", i, "consists of", nchar(i),
              "characters."))
}

## ----echo=TRUE----------------------------------------------------------------
dd = data.frame(x = rnorm(10), y = rnorm(10), z = rnorm(10))

max_cols = numeric(ncol(dd))
for (i in seq_along(dd)) {
  max_cols[i] = max(dd[, i])
}
max_cols

## -----------------------------------------------------------------------------
means = numeric(ncol(dd))
sds = numeric(ncol(dd))
for (i in seq_along(dd)) {
  means[i] = mean(dd[, i])
  sds[i] = sd(dd[, i])
}

## ----eval=FALSE, echo=TRUE----------------------------------------------------
#  vignette("solutions1", package = "jrProgramming")

