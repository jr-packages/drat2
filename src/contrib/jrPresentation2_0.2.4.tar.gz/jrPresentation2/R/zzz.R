# Create an environment to store the slides url
# That way we don't need to keep adding the url to the
# border
zzz = new.env()
zzz$url  = ""
